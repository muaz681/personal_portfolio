<!-- all js here -->
        <script src="{{ url('assets/frontend/js/vendor/jquery-1.12.4.min.js') }}"></script>
        <script src="{{ url('assets/frontend/js/bootstrap.min.js') }}"></script>
        <script src="{{ url('assets/frontend/js/jquery.ajaxchimp.min.js') }}"></script>
        <script src="{{ url('assets/frontend/js/plugins.js') }}"></script>
        <script src="{{ url('assets/frontend/js/main.js') }}"></script>
        <script src="{{ url('assets/frontend/js/slick.min.js') }}"></script>


