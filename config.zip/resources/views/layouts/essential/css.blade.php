        <!-- all css here -->
        <link rel="stylesheet" href="{{ url('assets/frontend/css/bootstrap.min.css') }}">
        <link rel="stylesheet" href="{{ url('assets/frontend/css/font-awesome.min.css') }}">
        <link rel="stylesheet" href="{{ url('assets/frontend/css/material-design-iconic-font.min.css') }}">
        <link rel="stylesheet" href="{{ url('assets/frontend/css/magnific-popup.css') }}">
        <link rel="stylesheet" href="{{ url('assets/frontend/css/meanmenu.min.css') }}">
        <link rel="stylesheet" href="{{ url('assets/frontend/css/plugins.css') }}">
        <link rel="stylesheet" href="{{ url('assets/frontend/css/shortcode/shortcodes.css') }}">
        <link rel="stylesheet" href="{{ url('assets/frontend/style.css') }}">
        <link rel="stylesheet" href="{{ url('assets/frontend/css/responsive.css') }}">
        <link rel="stylesheet" href="{{ url('assets/frontend/css/slick.css') }}">
        <link rel="stylesheet" href="{{ url('assets/frontend/css/slick-theme.css') }}">
        <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
        <script src="{{ url('assets/frontend/js/vendor/modernizr-2.8.3.min.js') }}"></script>
